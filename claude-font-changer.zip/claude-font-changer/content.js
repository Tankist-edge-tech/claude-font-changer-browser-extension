// Applies the chosen font settings to claude.ai and updates live when they change.
(() => {
  const STYLE_ID = "claude-font-changer-style";
  const DEFAULTS = {
    enabled: true,
    font: "",        // "" = keep Claude's default
    codeFont: "",    // "" = keep Claude's default
    size: 100,       // percent
    lineHeight: 0    // 0 = keep default
  };

  const quote = (name) => `"${String(name).replace(/["\\]/g, "")}"`;

  function buildCss(s) {
    if (!s.enabled) return "";
    let css = "";

    if (s.size && Number(s.size) !== 100) {
      css += `html { font-size: ${Number(s.size)}% !important; }\n`;
    }

    if (s.font) {
      const stack = `${quote(s.font)}, system-ui, sans-serif`;
      css += `
body, body *:not(pre):not(code):not(kbd):not(samp)
  :not(pre *):not(code *):not(.katex):not(.katex *) {
  font-family: ${stack} !important;
}
input, textarea, button, select, [contenteditable="true"], [contenteditable="true"] * {
  font-family: ${stack} !important;
}\n`;
    }

    if (s.codeFont) {
      const stack = `${quote(s.codeFont)}, ui-monospace, monospace`;
      css += `pre, code, kbd, samp, pre *, code * { font-family: ${stack} !important; }\n`;
    }

    if (s.lineHeight && Number(s.lineHeight) > 0) {
      css += `body p, body li, body blockquote, [contenteditable="true"] p {
  line-height: ${Number(s.lineHeight)} !important;
}\n`;
    }

    return css;
  }

  let currentCss = "";

  function ensureStyle() {
    let el = document.getElementById(STYLE_ID);
    if (!el) {
      el = document.createElement("style");
      el.id = STYLE_ID;
      (document.head || document.documentElement).appendChild(el);
    }
    if (el.textContent !== currentCss) el.textContent = currentCss;
    // Keep our style last so it wins over styles the page adds later.
    if (el.parentNode && el.parentNode.lastElementChild !== el && document.head) {
      document.head.appendChild(el);
    }
  }

  function apply(settings) {
    currentCss = buildCss({ ...DEFAULTS, ...settings });
    ensureStyle();
  }

  chrome.storage.sync.get(DEFAULTS, apply);

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "sync") return;
    chrome.storage.sync.get(DEFAULTS, apply);
  });

  // Claude's page can rebuild <head>; re-add our style if it disappears.
  new MutationObserver(() => {
    if (!document.getElementById(STYLE_ID)) ensureStyle();
  }).observe(document.documentElement, { childList: true, subtree: true });
})();
