# Claude Font Changer

A small Chrome extension that changes the font, text size and line spacing on claude.ai.

## Install

1. Unzip `claude-font-changer.zip` into a folder you'll keep (don't delete it later).
2. Open Chrome and go to `chrome://extensions`.
3. Turn on **Developer mode** (top-right).
4. Click **Load unpacked** and select the unzipped `claude-font-changer` folder.
5. Pin the extension (puzzle-piece icon → pin) so its button is in the toolbar.

## Use

Open claude.ai, click the extension's button and pick:

- **Text font**: any font installed on your computer (use the search box to find one).
- **Code font**: font for code blocks (monospace fonts listed first).
- **Text size**: scales Claude's whole interface, 75–150%.
- **Line spacing**: spacing between lines in messages ("default" at the far left).

Changes apply instantly and are remembered. The toggle switch turns everything off;
**Reset** returns to Claude's defaults.

## Notes

- Only fonts installed on your computer are listed. To use a new font (e.g. from
  Google Fonts), install it in Windows/macOS first, then restart Chrome.
- If Claude updates its site and something stops applying, reload the claude.ai tab.
