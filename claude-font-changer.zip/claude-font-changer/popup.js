const DEFAULTS = { enabled: true, font: "", codeFont: "", size: 100, lineHeight: 0 };
const $ = (id) => document.getElementById(id);

let settings = { ...DEFAULTS };
let allFonts = [];

function getFonts() {
  return new Promise((resolve) => {
    if (chrome.fontSettings && chrome.fontSettings.getFontList) {
      chrome.fontSettings.getFontList((list) =>
        resolve(list.map((f) => f.fontId).sort((a, b) => a.localeCompare(b)))
      );
    } else {
      resolve(["Arial", "Georgia", "Segoe UI", "Verdana", "Times New Roman", "Consolas", "Courier New"]);
    }
  });
}

function option(value, label) {
  const o = document.createElement("option");
  o.value = value;
  o.textContent = label;
  if (value) o.style.fontFamily = `"${value}"`;
  return o;
}

function fillFontList(filter = "") {
  const sel = $("font");
  sel.innerHTML = "";
  sel.appendChild(option("", "Claude's default"));
  const f = filter.trim().toLowerCase();
  allFonts
    .filter((name) => !f || name.toLowerCase().includes(f))
    .forEach((name) => sel.appendChild(option(name, name)));
  sel.value = settings.font;
  if (sel.value !== settings.font) sel.selectedIndex = -1;
}

function fillCodeList() {
  const sel = $("codeFont");
  sel.innerHTML = "";
  sel.appendChild(option("", "Claude's default"));
  const mono = /mono|code|consol|courier|menlo|fira|cascadia|jetbrains|hack|inconsolata|source code|ubuntu mono|lucida console/i;
  const monoFonts = allFonts.filter((n) => mono.test(n));
  const others = allFonts.filter((n) => !mono.test(n));
  const g1 = document.createElement("optgroup");
  g1.label = "Monospace";
  monoFonts.forEach((n) => g1.appendChild(option(n, n)));
  const g2 = document.createElement("optgroup");
  g2.label = "Other fonts";
  others.forEach((n) => g2.appendChild(option(n, n)));
  if (monoFonts.length) sel.appendChild(g1);
  sel.appendChild(g2);
  sel.value = settings.codeFont;
}

function render() {
  $("enabled").checked = settings.enabled;
  $("controls").classList.toggle("off", !settings.enabled);
  $("size").value = settings.size;
  $("sizeOut").textContent = `${settings.size}%`;
  $("lineHeight").value = settings.lineHeight;
  $("lineOut").textContent = Number(settings.lineHeight) > 0 ? Number(settings.lineHeight).toFixed(1) : "default";

  const p = $("preview");
  p.style.fontFamily = settings.font ? `"${settings.font}", system-ui, sans-serif` : "";
  p.style.fontSize = `${14 * settings.size / 100}px`;
  p.style.lineHeight = Number(settings.lineHeight) > 0 ? settings.lineHeight : "";
  p.querySelector("code").style.fontFamily =
    settings.codeFont ? `"${settings.codeFont}", monospace` : "ui-monospace, monospace";
}

function save(patch) {
  settings = { ...settings, ...patch };
  chrome.storage.sync.set(settings);
  render();
}

(async () => {
  settings = await chrome.storage.sync.get(DEFAULTS);
  allFonts = await getFonts();
  fillFontList();
  fillCodeList();
  render();

  $("enabled").addEventListener("change", (e) => save({ enabled: e.target.checked }));
  $("fontFilter").addEventListener("input", (e) => fillFontList(e.target.value));
  $("font").addEventListener("change", (e) => save({ font: e.target.value }));
  $("codeFont").addEventListener("change", (e) => save({ codeFont: e.target.value }));
  $("size").addEventListener("input", (e) => save({ size: Number(e.target.value) }));
  $("lineHeight").addEventListener("input", (e) => save({ lineHeight: Number(e.target.value) }));
  $("reset").addEventListener("click", () => {
    $("fontFilter").value = "";
    save({ ...DEFAULTS });
    fillFontList();
    fillCodeList();
  });
})();
